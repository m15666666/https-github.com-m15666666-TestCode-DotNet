# NModbus.Tools
A suite of tools for working with Modbus devices.

### Frame Parser
Simple tool for parsing Modbus frames logged from NModbus.

### Modbus Slave Explorer
Graphic interface for getting and settings values on Modbus slave devices.

### Modbus Slave Simulator
Simulates one or more Modbus slave devices.
