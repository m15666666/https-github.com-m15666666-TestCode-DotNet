﻿using System.Windows.Controls;

namespace NModbus.Tools.FrameParser.View
{
    /// <summary>
    /// Interaction logic for FrameParserView.xaml
    /// </summary>
    public partial class FrameParserView : UserControl
    {
        public FrameParserView()
        {
            InitializeComponent();
        }
    }
}
