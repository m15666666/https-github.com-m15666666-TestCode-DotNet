﻿namespace NModbus.Tools.Base.View
{
    /// <summary>
    /// Interaction logic for ConnectionSelectionDialog.xaml
    /// </summary>
    public partial class ConnectionSelectionDialog
    {
        public ConnectionSelectionDialog()
        {
            InitializeComponent();
        }
    }
}
