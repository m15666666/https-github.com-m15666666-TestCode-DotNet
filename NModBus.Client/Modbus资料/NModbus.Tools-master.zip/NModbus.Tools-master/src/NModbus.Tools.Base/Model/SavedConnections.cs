﻿namespace NModbus.Tools.Base.Model
{
    public class SavedConnections
    {
        public Connection[] Connections { get; set; }
    }
}
