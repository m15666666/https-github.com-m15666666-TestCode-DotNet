﻿namespace NModbus.Tools.Base
{
    public interface IMessageBoxService
    {
        void Show(string caption, string title);
    }
}
