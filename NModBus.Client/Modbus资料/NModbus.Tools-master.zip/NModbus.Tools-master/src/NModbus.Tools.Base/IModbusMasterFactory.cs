﻿namespace NModbus.Tools.Base
{
    public interface IModbusMasterFactory
    {
        IModbusMaster Create();
    }
}
