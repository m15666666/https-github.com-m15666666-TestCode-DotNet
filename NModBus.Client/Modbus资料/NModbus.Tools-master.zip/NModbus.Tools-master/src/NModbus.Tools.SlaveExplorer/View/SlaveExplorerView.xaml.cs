﻿namespace NModbus.Tools.SlaveExplorer.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class SlaveExplorerView
    {
        public SlaveExplorerView()
        {
            InitializeComponent();

            
        }
    }
}
