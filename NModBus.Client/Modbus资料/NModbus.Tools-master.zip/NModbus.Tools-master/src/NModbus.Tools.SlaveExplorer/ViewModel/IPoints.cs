﻿namespace NModbus.Tools.SlaveExplorer.ViewModel
{
    public interface IPoints
    {
        void Read();
    }
}
