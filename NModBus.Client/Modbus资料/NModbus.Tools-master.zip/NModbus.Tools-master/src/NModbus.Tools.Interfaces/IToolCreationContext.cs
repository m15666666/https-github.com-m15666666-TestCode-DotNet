﻿namespace NModbus.Tools.Interfaces
{
    public interface IToolCreationContext
    {
        IToolFactory Factory { get; }   
    }
}