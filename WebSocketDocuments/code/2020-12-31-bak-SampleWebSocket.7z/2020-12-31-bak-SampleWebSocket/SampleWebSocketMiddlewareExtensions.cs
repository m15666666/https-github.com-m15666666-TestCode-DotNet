using Microsoft.Extensions.DependencyInjection;

using SampleWebSocket;

namespace Microsoft.AspNetCore.Builder
{
    public static class SampleWebSocketMiddlewareExtensions
    {
        public static IApplicationBuilder UseSampleWebSockets(this IApplicationBuilder app)
        {

            var options = app.ApplicationServices.GetRequiredService<SampleWebSocketOptions>();

            app.UseWebSockets(options);
            return app.UseMiddleware<SampleWebSocketMiddleware>();
        }
    }

}
