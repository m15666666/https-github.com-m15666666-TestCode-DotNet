using Microsoft.AspNetCore.Http;
using SampleWebSocket.Models;

using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Builder;
using SampleWebSocket.Hubs;
using SampleWebSocket.Common;

namespace SampleWebSocket
{
    public class SampleWebSocketMiddleware : IMiddleware
    {

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            // 判断是否为websocket请求
            if (!context.WebSockets.IsWebSocketRequest)
            {
                await next(context);
                return;
            }

            // 路由配置
            var options = context.RequestServices.GetRequiredService<SampleWebSocketOptions>();

            // 匹配路由
            var requestPath = context.Request.Path.Value.ToLower();
            if (!options.Routes.TryGetValue(requestPath, out var route))
            {
                await next(context);
                return;
            }

            try
            {
                // 解析请求
                //using (var webSocket = await context.WebSockets.AcceptWebSocketAsync())
                //{
                //    var requestPairs = GetRequestPairs(context);

                //    var hub = context.RequestServices.GetRequiredService(route.HubType) as IWebSocketHub<WebSocketMessage>;

                //    await hub?.AddWebSocket(requestPairs, webSocket);
                //}

                // TODO:解析请求
                var webSocket = await context.WebSockets.AcceptWebSocketAsync();
                var sn = context.Request.Query["sn"];
                var hub = context.RequestServices.GetRequiredService(route.HubType) as ISampleWsHub<WebSocketMessage>;
                var aspNetCoreWsConnection = new AspNetCoreWsConnection<WebSocketMessage>(sn, webSocket, new StringWebSocketSerializer());
                await hub?.AddWsConnection(sn, aspNetCoreWsConnection);
            }
            catch (Exception ex)
            {
                var logger = context.RequestServices.GetRequiredService<ILogger<WebSocketMessage>>();

                logger.LogError(ex, ex.Message);
            }
        }

        /// <summary>
        /// 获取请求参数，传递给websocket hub
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        protected virtual Dictionary<string, string> GetRequestPairs(HttpContext context)
        {
            var result = new Dictionary<string, string>();
            foreach (var item in context.Request.Query)
            {
                result.Add(item.Key, item.Value);
            }
            foreach (var item in context.Request.Headers)
            {
                result.Add(item.Key, item.Value);
            }

            return result;
        }
    }

}
