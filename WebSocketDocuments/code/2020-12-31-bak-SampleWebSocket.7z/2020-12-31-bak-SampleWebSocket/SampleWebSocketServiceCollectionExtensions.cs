using Microsoft.AspNetCore.Builder;

using SampleWebSocket;

using System;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class SampleWebSocketServiceCollectionExtensions
    {
        public static IServiceCollection AddSampleWebSocket(this IServiceCollection services, Action<SampleWebSocketOptions> configOptions)
        {
            var options = new SampleWebSocketOptions();
            configOptions?.Invoke(options);

            services.AddSingleton(options);

            services.AddScoped<SampleWebSocketMiddleware>();

            return services;
        }
    }
}
