using Newtonsoft.Json;

using System;
using System.Collections.Generic;
using System.Text;

namespace SampleWebSocket.Hubs
{
    public interface IWebSocketSerializer
    {
        byte[] Serialize(object input);

        T Deserialize<T>(byte[] input);
        T Deserialize<T>(string input);
        object Deserialize(byte[] input, Type type);
        object Deserialize(string input, Type type);
    }

    public class StringWebSocketSerializer : IWebSocketSerializer
    {
        static Type _stringType = typeof(string);
        static JsonSerializerSettings _formatOptions = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore
        };

        public T Deserialize<T>(byte[] input)
        {
            var jsonString = BytesToString(input);

            if (typeof(T).FullName == _stringType.FullName)
            {
                return (T)(object)jsonString;
            }

            return JsonConvert.DeserializeObject<T>(jsonString, _formatOptions);
        }

        public object Deserialize(byte[] input, Type type)
        {
            var jsonString = BytesToString(input);

            if (type.FullName == _stringType.FullName)
            {
                return jsonString;
            }

            return JsonConvert.DeserializeObject(jsonString, type, _formatOptions);
        }

        public T Deserialize<T>(string input)
        {
            return JsonConvert.DeserializeObject<T>(input, _formatOptions);
        }

        public object Deserialize(string input, Type type)
        {
            return JsonConvert.DeserializeObject(input, type, _formatOptions);
        }

        public byte[] Serialize(object input)
        {
            var jsonString = string.Empty;
            if (input.GetType().FullName == _stringType.FullName)
            {
                jsonString = (string)input;
            }
            else
            {
                jsonString = JsonConvert.SerializeObject(input, _formatOptions);
            }


            return this.StringToBytes(jsonString);
        }

        protected virtual string BytesToString(byte[] input)
        {
            return Encoding.ASCII.GetString(input);
        }

        protected virtual byte[] StringToBytes(string input)
        {
            return Encoding.ASCII.GetBytes(input);
        }
    }
}
