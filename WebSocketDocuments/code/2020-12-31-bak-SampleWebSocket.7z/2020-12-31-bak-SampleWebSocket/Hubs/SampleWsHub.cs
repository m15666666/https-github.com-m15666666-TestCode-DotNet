using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

using Riven.Storage;

using SampleWebSocket.Common;
using SampleWebSocket.Models;

namespace SampleWebSocket.Hubs
{
    public abstract class SampleWsHub<TReceive> : AnyStorageBase<IWebSocketConnection<TReceive>>, ISampleWsHub<TReceive>
        where TReceive : WebSocketMessage, new()
    {
        protected int _disposed;

        protected readonly ConcurrentDictionary<string, string> _connectionIdKeyDict;
        protected readonly IWebSocketSerializer _serializer;

        public SampleWsHub()
        {
            this._connectionIdKeyDict = new ConcurrentDictionary<string, string>();
            this._serializer = new StringWebSocketSerializer();
        }

        public IEnumerable<IWebSocketConnection<TReceive>> GetAll(Expression<Func<IWebSocketConnection<TReceive>, bool>> expression)
        {
            return this._dataMap.Values.Where(expression.Compile());
        }

        public List<Task<TReceive>> CreateSendTask(string[] ids, object input, int timeout)
        {
            // 命令id
            var cmdId = $"{input.GetHashCode()}{DateTime.Now.GetHashCode()}";
            // 消息体
            var msg = new TReceive();
            msg.CmdId = cmdId;
            msg.Data = input;

            // 创建msg
            var cmd = this.CreateCmd(msg);


            var connections = this.GetAll(o => ids.Contains(o.Identifier)).ToArray();
            var resultTasks = new List<Task<TReceive>>();

            foreach (var connection in connections)
            {
                resultTasks.Add(connection.SendReceive(cmd, timeout, cmdId));
            }

            return resultTasks;
        }

        /// <summary>
        /// 创建命令
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        protected virtual object CreateCmd(TReceive input)
        {
            return input;
        }

        #region 管理连接

        public virtual Task AddWsConnection(string key, IWebSocketConnection<TReceive> connection)
        {
            this.AddOrUpdate(key, connection);

            var originalConnectionId = connection.OriginalIdentifier;
            this._connectionIdKeyDict.AddOrUpdate(originalConnectionId, key, (k, v) =>
            {
                return key;
            });

            this.AddEvent(connection);

            return Task.CompletedTask;
        }

        /// <summary>
        /// 删除连接
        /// </summary>
        /// <param name="connection"></param>
        public virtual void RemoveConnection(IWebSocketConnection<TReceive> connection)
        {
            var originalConnectionId = connection.OriginalIdentifier;
            this._connectionIdKeyDict.TryRemove(originalConnectionId, out var key);
            this.Remove(connection.Identifier);
        }


        /// <summary>
        /// 根据原始连接标识符原删除连接
        /// </summary>
        /// <param name="session"></param>
        public virtual void RemoveConnectionByOriginalIdentifier(string originalIdentifier)
        {
            if (!this._connectionIdKeyDict.TryRemove(originalIdentifier, out var key))
            {
                return;
            }

            this.Remove(key);
        }

        #endregion


        #region 重写 AnyStorageBase 的公开函数 

        public override void AddOrUpdate(string key, IWebSocketConnection<TReceive> val)
        {
            this._dataMap.AddOrUpdate(key, val, (k, v) =>
            {
                // 释放
                this.RemoveEvent(v);
                v.Dispose();

                return val;
            });
        }

        public override void Remove(string key)
        {
            if (this._dataMap.TryRemove(key, out var connection))
            {
                // 释放
                this.RemoveEvent(connection);
                connection.Dispose();

                return;
            }
        }

        #endregion



        #region 事件监听

        /// <summary>
        /// 给连接添加事件
        /// </summary>
        /// <param name="connection"></param>
        protected virtual void AddEvent(IWebSocketConnection<TReceive> connection)
        {
            connection.OnReceive += Connection_OnReceive;
            connection.OnDisconnect += Connection_OnDisconnect;
            connection.OnException += Connection_OnException;
        }

        /// <summary>
        /// 删除连接的事件
        /// </summary>
        /// <param name="connection"></param>
        protected virtual void RemoveEvent(IWebSocketConnection<TReceive> connection)
        {
            connection.OnReceive -= Connection_OnReceive;
            connection.OnDisconnect -= Connection_OnDisconnect;
            connection.OnException -= Connection_OnException;
        }


        protected virtual async void Connection_OnReceive(object sender, TReceive e)
        {
            var connection = (sender as IWebSocketConnection<TReceive>);

            await this.OnReceive(connection, e);
        }

        /// <summary>
        /// 消息来临
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        protected abstract Task OnReceive(IWebSocketConnection<TReceive> connection, TReceive e);

        protected virtual async void Connection_OnException(object sender, Exception e)
        {
            var connection = (sender as IWebSocketConnection<TReceive>);

            await this.OnException(connection, e);
        }

        /// <summary>
        /// 发生异常
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        protected abstract Task OnException(IWebSocketConnection<TReceive> connection, Exception e);

        protected virtual async void Connection_OnDisconnect(object sender, string e)
        {
            var connection = (sender as IWebSocketConnection<TReceive>);
            await this.OnDisconnect(connection);

            this.RemoveConnection(connection);
        }

        /// <summary>
        /// 断开连接
        /// </summary>
        /// <param name="connection"></param>
        /// <returns></returns>
        protected abstract Task OnDisconnect(IWebSocketConnection<TReceive> connection);

        #endregion


        #region 释放资源

        public async ValueTask DisposeAsync()
        {
            if (_disposed == 1)
            {
                return;
            }
            Interlocked.Increment(ref this._disposed);

            // 释放连接信息
            foreach (var connection in this._dataMap)
            {
                // 释放事件
                this.RemoveEvent(connection.Value);
                // 释放连接
                connection.Value.Dispose();
            }
            _dataMap.Clear();
            _connectionIdKeyDict.Clear();


            await SelfDisposeAsync();

            GC.SuppressFinalize(this);
        }

        public abstract ValueTask SelfDisposeAsync();



        #endregion
    }
}
