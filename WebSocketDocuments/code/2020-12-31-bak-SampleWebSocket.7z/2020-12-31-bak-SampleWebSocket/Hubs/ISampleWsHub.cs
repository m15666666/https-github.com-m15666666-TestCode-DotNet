using System;
using System.Text;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

using Riven.Storage;

using SampleWebSocket.Common;
using SampleWebSocket.Models;
using System.Collections.Generic;
using System.Threading;

namespace SampleWebSocket.Hubs
{
    public interface ISampleWsHub<TReceive> : IAnyStorage<IWebSocketConnection<TReceive>>, IAsyncDisposable
        where TReceive : WebSocketMessage
    {
        /// <summary>
        /// 查询连接
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        IEnumerable<IWebSocketConnection<TReceive>> GetAll(Expression<Func<IWebSocketConnection<TReceive>, bool>> expression);

        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="key"></param>
        /// <param name="connection"></param>
        /// <returns></returns>
        Task AddWsConnection(string key, IWebSocketConnection<TReceive> connection);

        /// <summary>
        /// 删除连接
        /// </summary>
        /// <param name="connection"></param>
        void RemoveConnection(IWebSocketConnection<TReceive> connection);

        /// <summary>
        /// 根据原始连接标识符原删除连接
        /// </summary>
        /// <param name="originalIdentifier"></param>
        void RemoveConnectionByOriginalIdentifier(string originalIdentifier);

        /// <summary>
        /// 创建下发任务集合
        /// </summary>
        /// <param name="ids">标识数组</param>
        /// <param name="input">数据</param>
        /// <param name="timeout">超时时间(毫秒)</param>
        /// <returns></returns>
        List<Task<TReceive>> CreateSendTask(string[] ids, object input, int timeout);
    }
}
