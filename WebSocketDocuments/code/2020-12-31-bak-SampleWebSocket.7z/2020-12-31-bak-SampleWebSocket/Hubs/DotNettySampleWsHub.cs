using System;
using System.IO;
using System.Runtime;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;

using DotNetty.Buffers;
using DotNetty.Codecs.Http;
using DotNetty.Codecs.Http.WebSockets;
using DotNetty.Common;
using DotNetty.Common.Utilities;
using DotNetty.Handlers.Tls;
using DotNetty.Transport.Bootstrapping;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Sockets;
using DotNetty.Transport.Libuv;

using System.Text;
using System.Diagnostics;
using SampleWebSocket.Common;
using Riven.Storage;
using SampleWebSocket.Models;
using System.Collections.Concurrent;

namespace SampleWebSocket.Hubs
{
    public abstract class DotNettySampleWsHub<TReceive> : SampleWsHub<TReceive>
            where TReceive : WebSocketMessage, new()
    {

        readonly DotNettySampleWsOptions _options;

        #region dotnetty group & channel

        IEventLoopGroup _bossGroup;
        IEventLoopGroup _workGroup;
        IChannel _bootstrapChannel;

        #endregion


        public DotNettySampleWsHub(DotNettySampleWsOptions options)
        {
            _options = options;
            this.Init().GetAwaiter().GetResult();
        }


        /// <summary>
        /// 初始化
        /// </summary>
        /// <returns></returns>
        protected virtual async Task Init()
        {

            var dispatcher = new DispatcherEventLoopGroup();
            _bossGroup = dispatcher;
            _workGroup = new WorkerEventLoopGroup(dispatcher);



            var bootstrap = new ServerBootstrap();
            bootstrap.Group(_bossGroup, _workGroup);

            bootstrap.Channel<TcpServerChannel>();
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux)
                || RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                bootstrap
                    .Option(ChannelOption.SoReuseport, true)
                    .ChildOption(ChannelOption.SoReuseaddr, true);
            }

            bootstrap
                .Option(ChannelOption.SoBacklog, this._options.SoBacklog)
                .Option(ChannelOption.TcpNodelay, true)
                .ChildHandler(new ActionChannelInitializer<IChannel>(channel =>
                {
                    IChannelPipeline pipeline = channel.Pipeline;
                    if (this._options.IsSsl && this._options.TlsCertificate != null)
                    {
                        pipeline.AddLast(
                            TlsHandler.Server(this._options.TlsCertificate)
                            );
                    }
                    pipeline.AddLast(new HttpServerCodec());
                    pipeline.AddLast(new HttpObjectAggregator(65536));


                    var connection = new DotNettyWsConnection<TReceive>(
                             this._options.IsSsl,
                             this._options.MaxFramePayloadLength,
                             this._options.WebsocketPath,
                             this._serializer
                             );
                    connection.OnConnection += Connection_OnConnection;

                    pipeline.AddLast(connection);
                }));

            _bootstrapChannel = await bootstrap.BindAsync(
                this._options.IP,
                this._options.Port
                );
        }

        /// <summary>
        /// 释放资源
        /// </summary>
        /// <returns></returns>
        public async override ValueTask SelfDisposeAsync()
        {
            await this._bootstrapChannel?.CloseAsync();
            await this._bossGroup?.ShutdownGracefullyAsync();
            await this._workGroup?.ShutdownGracefullyAsync();
        }

        protected override object CreateCmd(TReceive input)
        {
            var buffer = this._serializer.Serialize(input);
            return buffer;
        }

        #region 事件监听

        protected override void RemoveEvent(IWebSocketConnection<TReceive> connection)
        {
            if (connection is DotNettyWsConnection<TReceive> nettyConnection)
            {
                nettyConnection.OnConnection -= Connection_OnConnection;
            }
            base.RemoveEvent(connection);
        }

        protected virtual async void Connection_OnConnection(object sender, IChannel e)
        {
            var connection = (sender as DotNettyWsConnection<TReceive>);
            await this.AddWsConnection(connection.Identifier, connection);
        }

        protected override Task OnDisconnect(IWebSocketConnection<TReceive> connection)
        {
            return Task.CompletedTask;
        }

        protected override Task OnException(IWebSocketConnection<TReceive> connection, Exception e)
        {
            return Task.CompletedTask;
        }

        #endregion
    }

    public class DotNettySampleWsOptions
    {
        /// <summary>
        /// default: <see cref="System.Net.IPAddress.Loopback"/>
        /// </summary>
        public System.Net.IPAddress IP { get; set; }

        /// <summary>
        /// default: 9000
        /// </summary>
        public int Port { get; set; }

        /// <summary>
        /// default: false
        /// </summary>
        public bool IsSsl { get; set; }

        /// <summary>
        /// default: null
        /// </summary>
        public X509Certificate2 TlsCertificate { get; set; }

        /// <summary>
        /// default: 8192
        /// </summary>
        public int SoBacklog { get; set; }

        /// <summary>
        /// default: true
        /// </summary>
        public bool TcpNodelay { get; set; }

        /// <summary>
        /// default: 1 * 1024 * 1024
        /// </summary>
        public int MaxFramePayloadLength { get; set; }

        /// <summary>
        /// default: /websocket
        /// </summary>
        public string WebsocketPath { get; set; }

        public DotNettySampleWsOptions()
        {
            IP = System.Net.IPAddress.Loopback;
            Port = 9000;
            SoBacklog = 8192;
            TcpNodelay = true;
            MaxFramePayloadLength = 1 * 1024 * 1024;
            WebsocketPath = "/websocket";
        }
    }



}
