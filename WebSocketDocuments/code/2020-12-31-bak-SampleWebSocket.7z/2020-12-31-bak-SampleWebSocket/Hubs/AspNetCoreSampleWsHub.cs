using System;
using System.Threading.Tasks;

using Riven;
using Riven.Storage;

using SampleWebSocket.Common;
using SampleWebSocket.Models;

namespace SampleWebSocket.Hubs
{
    public abstract class AspNetCoreSampleWsHub<TReceive> : SampleWsHub<TReceive>
            where TReceive : WebSocketMessage, new()
    {

        public override async Task AddWsConnection(string key, IWebSocketConnection<TReceive> connection)
        {
            this.AddOrUpdate(key, connection);
            var taskCompletionSource = new TaskCompletionSource<string>();

            connection.OnReceive += Connection_OnReceive;

            var onDisconnect = new EventHandler<string>((o, e) =>
            {
                this.Remove(key);
                taskCompletionSource.SetResult(string.Empty);
            });
            connection.OnDisconnect += onDisconnect;


            await taskCompletionSource.Task;

            connection.OnDisconnect -= onDisconnect;
        }

        protected override object CreateCmd(TReceive input)
        {
            var buffer = this._serializer.Serialize(input);

            return new ArraySegment<byte>(buffer, 0, buffer.Length);
        }



        #region 事件监听


        protected override Task OnDisconnect(IWebSocketConnection<TReceive> connection)
        {
            return Task.CompletedTask;
        }

        protected override Task OnException(IWebSocketConnection<TReceive> connection, Exception e)
        {
            return Task.CompletedTask;
        }

        #endregion


        public override async ValueTask SelfDisposeAsync()
        {
            await Task.CompletedTask;
        }
    }
}
