
using Riven.Storage;

using SampleWebSocket.Common;
using SampleWebSocket.Models;
using BeetleX;
using BeetleX.FastHttpApi;

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
using BeetleX.FastHttpApi.WebSockets;
using System.Threading.Tasks;

namespace SampleWebSocket.Hubs
{
    public abstract class BeetleXSampleWsHub<TReceive> : SampleWsHub<TReceive>
        where TReceive : WebSocketMessage, new()
    {
        bool _inited;

        readonly HttpApiServer _httpServer;

        public BeetleXSampleWsHub(HttpOptions httpOptions)
            : base()
        {
            _httpServer = new HttpApiServer(httpOptions);
            _httpServer.FrameSerializer = new BeetleXStringSerializer<TReceive>();


            this.Init();
        }

        private void Init()
        {
            if (_inited)
            {
                return;
            }
            this._inited = true;


            this._httpServer.WebSocketConnect = (o, e) =>
            {
                var key = this.GetKey(e.Request);
                var session = e.Request.Session;

                var connection = this.CreateConnection(key, session);
                this.AddWsConnection(key, connection);
            };

            this._httpServer.WebSocketReceive = new EventHandler<WebSocketReceiveArgs>((o, e) =>
            {
                var key = this.GetKey(e.Request);
                var session = e.Request.Session;


                var msg = e.Frame.Body as TReceive;

                var beetleXConnection = this.Get(key) as BeetleXConnection<TReceive>;
                beetleXConnection?.Receive(msg);
            });

            this._httpServer.HttpDisconnect += (o, e) =>
            {
                this.RemoveConnectionByOriginalIdentifier(e.Session.ID.ToString());
            };

            this._httpServer.Open();
        }

        protected override object CreateCmd(TReceive input)
        {
            return this._httpServer.CreateDataFrame(input);
        }

        #region 重写的公开函数

        public override void AddOrUpdate(string key, IWebSocketConnection<TReceive> val)
        {
            this._dataMap.AddOrUpdate(key, val, (k, v) =>
            {
                v.OnReceive -= Connection_OnReceive;
                v.Dispose();

                return val;
            });
        }

        public override void Remove(string key)
        {
            if (this._dataMap.TryRemove(key, out var connection))
            {
                (connection as BeetleXConnection<TReceive>)?.Disconnect();
                connection.OnReceive -= Connection_OnReceive;
                connection.Dispose();
                return;
            }
            Console.WriteLine("删除失败");
        }

        #endregion


        #region 内部函数 Connection 管理

        /// <summary>
        /// 创建连接
        /// </summary>
        /// <param name="key"></param>
        /// <param name="session"></param>
        /// <returns></returns>
        protected virtual BeetleXConnection<TReceive> CreateConnection(string key, ISession session)
        {
            return new BeetleXConnection<TReceive>(this._httpServer, key, session);
        }

        /// <summary>
        /// 获取键值,默认取sn
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        protected virtual string GetKey(HttpRequest request)
        {
            return request.Data["sn"];
        }


        #endregion


        #region 事件监听


        protected override Task OnDisconnect(IWebSocketConnection<TReceive> connection)
        {
            return Task.CompletedTask;
        }

        protected override Task OnException(IWebSocketConnection<TReceive> connection, Exception e)
        {
            return Task.CompletedTask;
        }

        #endregion

        #region 释放资源

        public override async ValueTask SelfDisposeAsync()
        {
            this._httpServer.Dispose();

            await Task.CompletedTask;
        }

        #endregion


    }
}