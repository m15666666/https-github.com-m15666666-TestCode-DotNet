using System;
using System.IO;
using System.Runtime;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;

using DotNetty.Buffers;
using DotNetty.Codecs.Http;
using DotNetty.Codecs.Http.WebSockets;
using DotNetty.Common;
using DotNetty.Common.Utilities;
using DotNetty.Handlers.Tls;
using DotNetty.Transport.Bootstrapping;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Sockets;
using DotNetty.Transport.Libuv;

using System.Text;
using System.Diagnostics;
using SampleWebSocket.Common;
using Riven.Storage;
using SampleWebSocket.Models;
using System.Web;
using SampleWebSocket.Hubs;
using System.Threading.Channels;
using System.Collections.Concurrent;
using SystemChannel = System.Threading.Channels.Channel;
using System.Collections.Specialized;
using System.Collections.Generic;

namespace SampleWebSocket.Common
{
    public class DotNettyWsConnection<TReceive> : DotNettyWebSocketServerHandler<TReceive>, IWebSocketConnection<TReceive>
              where TReceive : WebSocketMessage
    {
        protected int _disposed;

        public virtual event EventHandler<IChannel> OnConnection;
        public event EventHandler<TReceive> OnReceive;
        public event EventHandler<Exception> OnException;
        public event EventHandler<string> OnDisconnect;

        /// <summary>
        /// 序列化器
        /// </summary>
        readonly IWebSocketSerializer _serializer;

        #region 下发指令字典和队列

        /// <summary>
        /// 下发指令回调消息
        /// </summary>
        protected readonly Channel<TReceive> _callbackChannel;
        /// <summary>
        /// 下发指令回调消息函数
        /// </summary>
        protected readonly ConcurrentDictionary<string, Action<TReceive>> _callbackDict;
        /// <summary>
        /// 回调取消令牌
        /// </summary>
        protected readonly CancellationTokenSource _callbackReceiveCancellationTokenSource;
        /// <summary>
        /// 回调任务
        /// </summary>
        protected readonly Task _callbackReceiveTask;

        public string Identifier => this._identifier;

        public string OriginalIdentifier => this.Channel?.Id?.AsShortText();

        #endregion

        public DotNettyWsConnection(bool isSsl, int maxFramePayloadLength, string websocketPath, IWebSocketSerializer webSocketSerializer)
            : base(isSsl, maxFramePayloadLength, websocketPath)
        {
            this._serializer = webSocketSerializer;

            _callbackChannel = SystemChannel.CreateUnbounded<TReceive>();
            _callbackDict = new ConcurrentDictionary<string, Action<TReceive>>();
            _callbackReceiveCancellationTokenSource = new CancellationTokenSource();
            _callbackReceiveTask = Task.Factory.StartNew(CallbackReceive, _callbackReceiveCancellationTokenSource.Token);
        }

        public virtual async Task Send(object input, CancellationToken cancellationToken = default)
        {
            // 消息体
            if (input is byte[] inputBuffer)
            {
                // 推送消息
                await this.Channel?.WriteAndFlushAsync(
                    new TextWebSocketFrame(Unpooled.WrappedBuffer(inputBuffer))
                    );
            }
            else
            {
                var buffer = _serializer.Serialize(input);
                await this.Channel?.WriteAndFlushAsync(
                    new TextWebSocketFrame(Unpooled.WrappedBuffer(buffer))
                    );
            }

        }

        public async virtual Task<TReceive> SendReceive(object input, int timeout = 10000, string cmdId = null)
        {
            string selfCmdId = cmdId;
            // 自动生成命令id
            if (string.IsNullOrWhiteSpace(cmdId))
            {
                selfCmdId = $"{this._identifier.GetHashCode()}{input.GetHashCode()}{DateTime.Now.GetHashCode()}";
            }

            // 回调消息状态机
            var taskCompletionSource = new TaskCompletionSource<TReceive>();

            // 超时token
            var cancellationTokenSource = new CancellationTokenSource(timeout);
            Action dispose = () =>
            {
                cancellationTokenSource?.Dispose();
            };

            // 注册任务超时
            var cancellationTokenRegistration = cancellationTokenSource.Token.Register(
                () =>
                {
                    // 取消
                    //taskCompletionSource.SetCanceled();
                    taskCompletionSource.TrySetResult(null);

                    // 释放资源
                    dispose.Invoke();
                },
                useSynchronizationContext: false
                );

            // 添加回调
            this.AddCallback(selfCmdId, (msg) =>
            {
                // 设置结果
                taskCompletionSource.TrySetResult(msg);
                // 释放资源
                dispose.Invoke();
            });


            // 推送消息
            if (string.IsNullOrWhiteSpace(cmdId))
            {
                // 组织消息体
                var msg = new WebSocketMessage();
                msg.CmdId = selfCmdId;
                msg.Data = input;
                await this.Send(msg, CancellationToken.None);
            }
            else
            {
                await this.Send(input, CancellationToken.None);
            }

            try
            {
                // 等待回复
                return await taskCompletionSource.Task;
            }
            catch (Exception e)
            {
                return null;
            }
            finally
            {
                // 删除回调
                this.RemoveCallback(selfCmdId);
            }
        }

        #region 下发回调处理器函数

        /// <summary>
        /// 处理下发回调
        /// </summary>
        /// <returns></returns>
        protected async virtual Task CallbackReceive()
        {
            while (await _callbackChannel.Reader.WaitToReadAsync())
            {
                if (!_callbackChannel.Reader.TryRead(out var msg))
                {
                    continue;
                }

                if (!_callbackDict.TryGetValue(msg.CmdId, out var callback))
                {
                    continue;
                }

                callback?.Invoke(msg);
            }
        }

        #endregion


        #region 回调函数管理

        /// <summary>
        /// 添加回调函数
        /// </summary>
        /// <param name="key"></param>
        /// <param name="action"></param>
        public void AddCallback(string key, Action<TReceive> callback)
        {
            this._callbackDict.TryAdd(key, callback);
        }

        /// <summary>
        /// 删除回调函数
        /// </summary>
        /// <param name="key"></param>
        public void RemoveCallback(string key)
        {
            this._callbackDict.TryRemove(key, out var callback);
        }

        #endregion


        #region 基类函数，连接/消息/断开/异常

        protected override void Connection(IChannelHandlerContext ctx)
        {
            this.OnConnection(this, ctx.Channel);
        }

        protected override void Disconnect()
        {
            this.OnDisconnect?.Invoke(this, string.Empty);
        }

        protected override void Exception(Exception e)
        {
            this.OnException?.Invoke(this, e);
        }

        protected override void Receive(string input)
        {
            var msg = _serializer.Deserialize<TReceive>(input);

            msg.SId = this._identifier;
            // 分发
            if (string.IsNullOrWhiteSpace(msg.CmdId))
            {
                // 普通消息
                this.OnReceive?.Invoke(this, msg);
            }
            else
            {
                // 下发命令回调
                _callbackChannel.Writer.TryWrite(msg);
            }
        }
        #endregion


        #region 释放资源

        public void Dispose()
        {
            this.DisposeAsync().GetAwaiter().GetResult();
        }

        public async ValueTask DisposeAsync()
        {
            if (_disposed == 1)
            {
                return;
            }
            Interlocked.Increment(ref this._disposed);

            _callbackReceiveCancellationTokenSource?.Dispose();
            _callbackReceiveTask?.Dispose();
            _callbackDict.Clear();
            _callbackChannel.Writer.TryComplete();

            await this._handshaker?.CloseAsync(this.Channel, new CloseWebSocketFrame());
            this._handshaker = null;

            await this._channelHandlerContext?.CloseAsync();
            this._channelHandlerContext = null;

            GC.SuppressFinalize(this);
        }

        #endregion
    }



    public abstract class DotNettyWebSocketServerHandler<TReceive> : SimpleChannelInboundHandler<object>
       where TReceive : WebSocketMessage
    {
        protected readonly bool _isSsl;
        protected readonly int _maxFramePayloadLength;
        protected readonly string _websocketPath;


        protected WebSocketServerHandshaker _handshaker;
        protected IChannelHandlerContext _channelHandlerContext;

        /// <summary>
        /// 连接编码
        /// </summary>
        protected string _identifier;

        public DotNettyWebSocketServerHandler(bool isSsl, int maxFramePayloadLength, string websocketPath)
        {
            _isSsl = isSsl;
            _maxFramePayloadLength = maxFramePayloadLength;
            _websocketPath = websocketPath;
        }

        public virtual IChannel Channel => this._channelHandlerContext?.Channel;


        /// <summary>
        /// 连接
        /// </summary>
        /// <param name="context"></param>
        public override void ChannelActive(IChannelHandlerContext context)
        {

        }

        /// <summary>
        /// 断开连接
        /// </summary>
        /// <param name="context"></param>
        public override void ChannelInactive(IChannelHandlerContext context)
        {
            this.Disconnect();
        }

        /// <summary>
        /// 收到消息
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="msg"></param>
        protected override void ChannelRead0(IChannelHandlerContext ctx, object msg)
        {
            if (msg is WebSocketFrame frame)
            {
                this.HandleWebSocketFrame(ctx, frame);
            }
            else if (msg is IFullHttpRequest request)
            {
                this.HandleHttpRequest(ctx, request);
            }
        }


        public override void ChannelReadComplete(IChannelHandlerContext context)
        {
            context.Flush();
        }

        /// <summary>
        /// 出现异常
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="e"></param>
        public override void ExceptionCaught(IChannelHandlerContext ctx, Exception e)
        {
            ctx.CloseAsync();
            this.Exception(e);
        }

        /// <summary>
        /// 处理http请求（websocket首次建立连接）
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="req"></param>
        protected virtual void HandleHttpRequest(IChannelHandlerContext ctx, IFullHttpRequest req)
        {
            // Handle a bad request.
            if (!req.Result.IsSuccess)
            {
                SendHttpResponse(
                    ctx,
                    req,
                    new DefaultFullHttpResponse(HttpVersion.Http11, HttpResponseStatus.BadRequest)
                    );
                return;
            }

            // Allow only GET methods.
            if (!Equals(req.Method, HttpMethod.Get))
            {
                SendHttpResponse(
                    ctx,
                    req,
                    new DefaultFullHttpResponse(HttpVersion.Http11, HttpResponseStatus.Forbidden)
                    );
                return;
            }

            // Send the demo page and favicon.ico
            if ("/".Equals(req.Uri))
            {
                IByteBuffer content = Unpooled.WrappedBuffer(
                    Encoding.ASCII.GetBytes("<div>hello world</div>")
                );
                var res = new DefaultFullHttpResponse(
                    HttpVersion.Http11,
                    HttpResponseStatus.OK,
                    content);

                res.Headers.Set(HttpHeaderNames.ContentType, "text/html; charset=UTF-8");
                HttpUtil.SetContentLength(res, content.ReadableBytes);

                SendHttpResponse(ctx, req, res);
                return;
            }
            if ("/favicon.ico".Equals(req.Uri))
            {
                var res = new DefaultFullHttpResponse(
                    HttpVersion.Http11,
                    HttpResponseStatus.NotFound
                    );
                SendHttpResponse(ctx, req, res);
                return;
            }

            // 处理url，获取键值
            var url = HttpUtility.UrlDecode(req.Uri);
            var startIndex = url.IndexOf("?") + 1;
            var endIndex = url.Length - startIndex;
            var queryString = url.Substring(startIndex, endIndex);
            var queryStringDict = HttpUtility.ParseQueryString(queryString);
            this._identifier = this.GetKey(queryStringDict);
            queryStringDict.Clear();
            queryStringDict = null;


            // Handshake
            var wsFactory = new WebSocketServerHandshakerFactory(
                GetWebSocketLocation(req, this._isSsl, this._websocketPath),
                null,
                true,
                this._maxFramePayloadLength,
                true
                );
            this._handshaker = wsFactory.NewHandshaker(req);
            if (this._handshaker == null)
            {
                WebSocketServerHandshakerFactory.SendUnsupportedVersionResponse(ctx.Channel);
            }
            else
            {
                this._channelHandlerContext = ctx;
                this.Connection(this._channelHandlerContext);

                this._handshaker.HandshakeAsync(ctx.Channel, req);
            }


        }

        /// <summary>
        /// 处理websocket请求
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="frame"></param>
        protected virtual void HandleWebSocketFrame(IChannelHandlerContext ctx, WebSocketFrame frame)
        {
            // Check for closing frame
            if (frame is CloseWebSocketFrame)
            {
                this._handshaker.CloseAsync(ctx.Channel, (CloseWebSocketFrame)frame.Retain());
                return;
            }

            if (frame is PingWebSocketFrame)
            {
                ctx.WriteAsync(new PongWebSocketFrame((IByteBuffer)frame.Content.Retain()));
                return;
            }

            if (frame is TextWebSocketFrame textFrame)
            {
                this.Receive(
                    textFrame.Content.ToString(Encoding.ASCII)
                    );
                return;
            }

            //if (frame is BinaryWebSocketFrame binaryFrame)
            //{
            //    // Echo the frame
            //    //ctx.WriteAsync(frame.Retain());
            //}
        }

        /// <summary>
        /// 获取键值
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        protected virtual string GetKey(NameValueCollection input)
        {
            return input["sn"];
        }


        protected abstract void Exception(Exception e);

        protected abstract void Receive(string msg);

        protected abstract void Connection(IChannelHandlerContext ctx);

        protected abstract void Disconnect();



        #region 静态函数

        /// <summary>
        /// 发送http响应
        /// </summary>
        /// <param name="ctx">上下文</param>
        /// <param name="req">请求</param>
        /// <param name="res">响应</param>
        protected static void SendHttpResponse(IChannelHandlerContext ctx, IFullHttpRequest req, IFullHttpResponse res)
        {
            // Generate an error page if response getStatus code is not OK (200).
            if (res.Status.Code != 200)
            {
                IByteBuffer buf = Unpooled.CopiedBuffer(Encoding.UTF8.GetBytes(res.Status.ToString()));
                res.Content.WriteBytes(buf);
                buf.Release();
                HttpUtil.SetContentLength(res, res.Content.ReadableBytes);
            }

            // Send the response and close the connection if necessary.
            Task task = ctx.Channel.WriteAndFlushAsync(res);
            if (!HttpUtil.IsKeepAlive(req) || res.Status.Code != 200)
            {
                task.ContinueWith((t, c) => ((IChannelHandlerContext)c).CloseAsync(),
                    ctx, TaskContinuationOptions.ExecuteSynchronously);
            }
        }


        /// <summary>
        /// 获取请求的url地址
        /// </summary>
        /// <param name="req"></param>
        /// <param name="isSsl"></param>
        /// <param name="websocketPath"></param>
        /// <returns></returns>
        protected static string GetWebSocketLocation(IFullHttpRequest req, bool isSsl, string websocketPath)
        {
            bool result = req.Headers.TryGet(HttpHeaderNames.Host, out ICharSequence value);
            Debug.Assert(result, "Host header does not exist.");
            string location = value.ToString() + websocketPath;


            if (isSsl)
            {
                return "wss://" + location;
            }
            else
            {
                return "ws://" + location;
            }
        }

        #endregion
    }
}
