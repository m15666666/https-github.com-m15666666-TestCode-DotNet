using SampleWebSocket.Models;

using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace SampleWebSocket.Common
{
    /// <summary>
    /// websocket连接基类
    /// </summary>
    public abstract class WebSocketConnectionBase<TReceive> : IWebSocketConnection<TReceive>
         where TReceive : WebSocketMessage
    {
        protected int _disposed;
        /// <summary>
        /// 连接编码
        /// </summary>
        protected string _identifier;
        /// <summary>
        /// 原始连接编码
        /// </summary>
        protected string _originalIdentifier;


        #region 下发指令字典和队列

        /// <summary>
        /// 下发指令回调消息
        /// </summary>
        protected readonly Channel<TReceive> _callbackChannel;
        /// <summary>
        /// 下发指令回调消息函数
        /// </summary>
        protected readonly ConcurrentDictionary<string, Action<TReceive>> _callbackDict;
        /// <summary>
        /// 回调取消令牌
        /// </summary>
        protected readonly CancellationTokenSource _callbackReceiveCancellationTokenSource;
        /// <summary>
        /// 回调任务
        /// </summary>
        protected readonly Task _callbackReceiveTask;

        #endregion

        public WebSocketConnectionBase()
        {
            _callbackChannel = Channel.CreateUnbounded<TReceive>();
            _callbackDict = new ConcurrentDictionary<string, Action<TReceive>>();
            _callbackReceiveCancellationTokenSource = new CancellationTokenSource();
            _callbackReceiveTask = Task.Factory.StartNew(CallbackReceive, _callbackReceiveCancellationTokenSource.Token);
        }

        /// <summary>
        /// 连接编码
        /// </summary>
        public virtual string Identifier => _identifier;

        /// <summary>
        /// 原始连接编码
        /// </summary>
        public virtual string OriginalIdentifier => this._originalIdentifier;

        #region 下发回调处理器函数

        /// <summary>
        /// 处理下发回调
        /// </summary>
        /// <returns></returns>
        protected async virtual Task CallbackReceive()
        {
            while (await _callbackChannel.Reader.WaitToReadAsync())
            {
                if (!_callbackChannel.Reader.TryRead(out var msg))
                {
                    continue;
                }

                if (!_callbackDict.TryGetValue(msg.CmdId, out var callback))
                {
                    continue;
                }

                callback?.Invoke(msg);
                RemoveCallback(msg.CmdId);
            }
        }

        #endregion


        #region 事件

        public abstract event EventHandler<TReceive> OnReceive;
        public abstract event EventHandler<Exception> OnException;
        public abstract event EventHandler<string> OnDisconnect;

        #endregion


        #region 回调函数管理

        /// <summary>
        /// 添加回调函数
        /// </summary>
        /// <param name="key"></param>
        /// <param name="action"></param>
        public void AddCallback(string key, Action<TReceive> callback)
        {
            this._callbackDict.TryAdd(key, callback);
        }

        /// <summary>
        /// 删除回调函数
        /// </summary>
        /// <param name="key"></param>
        public void RemoveCallback(string key)
        {
            this._callbackDict.TryRemove(key, out var callback);
        }

        #endregion


        public abstract Task Send(object input, CancellationToken cancellationToken = default);

        public async virtual Task<TReceive> SendReceive(object input, int timeout = 10000, string cmdId = null)
        {
            string selfCmdId = cmdId;
            // 自动生成命令id
            if (string.IsNullOrWhiteSpace(cmdId))
            {
                selfCmdId = $"{this._identifier.GetHashCode()}{input.GetHashCode()}{DateTime.Now.GetHashCode()}";
            }

            // 回调消息状态机
            var taskCompletionSource = new TaskCompletionSource<TReceive>();

            // 超时token
            var cancellationTokenSource = new CancellationTokenSource(timeout);
            Action dispose = () =>
            {
                cancellationTokenSource?.Dispose();
            };

            // 注册任务超时
            var cancellationTokenRegistration = cancellationTokenSource.Token.Register(
                () =>
                {
                    // 取消
                    //taskCompletionSource.SetCanceled();
                    taskCompletionSource.TrySetResult(null);

                    // 释放资源
                    dispose.Invoke();
                },
                useSynchronizationContext: false
                );

            // 添加回调
            this.AddCallback(selfCmdId, (msg) =>
            {
                // 设置结果
                taskCompletionSource.TrySetResult(msg);
                // 释放资源
                dispose.Invoke();
            });


            // 推送消息
            if (string.IsNullOrWhiteSpace(cmdId))
            {
                // 消息体
                var msg = new WebSocketMessage();
                msg.CmdId = selfCmdId;
                msg.Data = input;
                await this.Send(msg, CancellationToken.None);
            }
            else
            {
                await this.Send(input, CancellationToken.None);
            }

            try
            {
                // 等待回复
                return await taskCompletionSource.Task;
            }
            catch (Exception e)
            {
                return null;
            }
            finally
            {
                // 删除回调
                this.RemoveCallback(selfCmdId);
            }
        }
        public void Dispose()
        {
            this.DisposeAsync().GetAwaiter().GetResult();
        }

        public async ValueTask DisposeAsync()
        {
            if (_disposed == 1)
            {
                return;
            }
            Interlocked.Increment(ref this._disposed);

            _callbackReceiveCancellationTokenSource?.Dispose();
            _callbackReceiveTask?.Dispose();
            _callbackDict.Clear();
            _callbackChannel.Writer.TryComplete();

            await this.SelfDisposeAsync();

            GC.SuppressFinalize(this);
        }

        protected abstract ValueTask SelfDisposeAsync();


    }
}
