using DotNetty.Transport.Channels;

using SampleWebSocket.Hubs;
using SampleWebSocket.Models;

using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace SampleWebSocket.Common
{
    public class AspNetCoreWsConnection<TReceive> : WebSocketConnectionBase<TReceive>
            where TReceive : WebSocketMessage
    {

        /// <summary>
        /// websocket实例
        /// </summary>
        readonly WebSocket _webSocket;


        /// <summary>
        /// 接收消息的
        /// </summary>
        readonly ArraySegment<byte> _receiveSegment;
        /// <summary>
        /// 上传数据通道
        /// </summary>
        protected readonly Channel<TReceive> _channel;


        #region 消息监听任务
        readonly CancellationTokenSource _receiveCancellationTokenSource;
        readonly Task _receiveTask;
        #endregion



        public AspNetCoreWsConnection(string identifier, WebSocket webSocket, IWebSocketSerializer webSocketSerializer)
        {
            _identifier = identifier;
            _webSocket = webSocket;

            this.Serializer = webSocketSerializer;


            this._originalIdentifier = _webSocket.GetHashCode().ToString();

            // 初始化消息接收
            _receiveSegment = new ArraySegment<byte>(new byte[1024]);

            // 消息处理
            _channel = Channel.CreateUnbounded<TReceive>();


            // 消息监听
            _receiveCancellationTokenSource = new CancellationTokenSource();
            _receiveTask = Task.Factory.StartNew(Receive, _receiveCancellationTokenSource.Token);
        }

        public virtual IWebSocketSerializer Serializer { get; protected set; }

        #region 事件


        /// <summary>
        /// 消息
        /// </summary>
        public override event EventHandler<TReceive> OnReceive;

        /// <summary>
        /// 异常
        /// </summary>
        public override event EventHandler<Exception> OnException;

        /// <summary>
        /// 断开
        /// </summary>
        public override event EventHandler<string> OnDisconnect;

        #endregion


        /// <summary>
        /// 监听消息
        /// </summary>
        /// <returns></returns>
        public async Task Receive()
        {
            var result = default(WebSocketReceiveResult);

            // 等待消息
            try
            {
                do
                {
                    result = await _webSocket.ReceiveAsync(
                      _receiveSegment,
                      CancellationToken.None
                      );

                    // 反序列化数据
                    var msg = Serializer.Deserialize<TReceive>(
                        _receiveSegment.Array.Take(result.Count).ToArray()
                        );

                    msg.SId = this._identifier;

                    // 分发
                    if (string.IsNullOrWhiteSpace(msg.CmdId))
                    {
                        // 普通消息
                        this.OnReceive?.Invoke(this, msg);
                    }
                    else
                    {
                        // 下发命令回调
                        await _callbackChannel.Writer.WriteAsync(msg);
                    }

                } while (!result.CloseStatus.HasValue);
                await this.DisposeAsync();
            }
            catch (Exception ex)
            {
                this.OnException?.Invoke(this, ex);
                await this.DisposeAsync();
            }
        }



        public override async Task Send(object input, CancellationToken cancellationToken = default(CancellationToken))
        {
            if (input is ArraySegment<byte> arraySegment)
            {
                await this._webSocket.SendAsync(
                  arraySegment,
                  WebSocketMessageType.Text,
                  true,
                  cancellationToken
                  );
                return;
            }

            var buffer = this.Serializer.Serialize(input);
            await this._webSocket.SendAsync(
                  new ArraySegment<byte>(buffer, 0, buffer.Length),
                  WebSocketMessageType.Text,
                  true,
                  cancellationToken
                  );
        }



        #region 释放资源

        protected override async ValueTask SelfDisposeAsync()
        {
            if (_webSocket.State != WebSocketState.Closed &&
                _webSocket.State != WebSocketState.Aborted)
            {
                await _webSocket.CloseAsync(
                 WebSocketCloseStatus.Empty,
                 $"服务端主动断开与客户端的连接.   连接标识符: {_identifier}",
                 CancellationToken.None
                 );
            }

            // 断开连接
            _webSocket.Dispose();

            // 消息处理
            _receiveCancellationTokenSource.Cancel();
            _receiveCancellationTokenSource.Dispose();
            _receiveTask.Dispose();

            // 回调任务
            _callbackReceiveCancellationTokenSource.Cancel();
            _callbackReceiveCancellationTokenSource.Dispose();
            _callbackReceiveTask.Dispose();

            // 清空回调
            _callbackDict.Clear();

            // 触发断开
            this.OnDisconnect?.Invoke(this, this._identifier);

            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
