using SampleWebSocket.Models;

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SampleWebSocket.Common
{
    /// <summary>
    /// websocket连接
    /// </summary>
    public interface IWebSocketConnection<TReceive> : IDisposable, IAsyncDisposable
         where TReceive : WebSocketMessage
    {

        /// <summary>
        /// 消息
        /// </summary>
        event EventHandler<TReceive> OnReceive;

        /// <summary>
        /// 异常
        /// </summary>
        event EventHandler<Exception> OnException;

        /// <summary>
        /// 断开
        /// </summary>
        event EventHandler<string> OnDisconnect;


        /// <summary>
        /// 标识符
        /// </summary>
        string Identifier { get; }

        /// <summary>
        /// 原始连接标识
        /// </summary>
        string OriginalIdentifier { get; }

        /// <summary>
        /// 推送到客户端
        /// </summary>
        /// <param name="input">数据</param>
        /// <param name="cancellationToken">任务取消标识</param>
        /// <returns></returns>
        Task Send(object input, CancellationToken cancellationToken = default(CancellationToken));

        /// <summary>
        /// 推送到客户端并等待客户端响应
        /// </summary>
        /// <param name="input">数据</param>
        /// <param name="timeout">超时时间(毫秒)</param>
        /// <param name="cmdId">命令id，当input是已经处理好，只需要发送时使用</param>
        /// <returns></returns>
        Task<TReceive> SendReceive(object input, int timeout = 10000, string cmdId = null);
    }
}
