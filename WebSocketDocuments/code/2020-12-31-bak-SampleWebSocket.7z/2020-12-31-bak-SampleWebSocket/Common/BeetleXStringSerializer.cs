using BeetleX.Buffers;
using BeetleX.FastHttpApi.WebSockets;

using SampleWebSocket.Hubs;

using System;
using System.Linq;

namespace SampleWebSocket.Common
{
    public class BeetleXStringSerializer<TReceive> : IDataFrameSerializer
    {
        readonly IWebSocketSerializer _webSocketSerializer;
        readonly Type _receiveType;
        public BeetleXStringSerializer()
        {
            this._webSocketSerializer = new StringWebSocketSerializer();
            this._receiveType = typeof(TReceive);
        }

        public object FrameDeserialize(DataFrame data, PipeStream stream)
        {
            var len = (int)data.Length;

            return this._webSocketSerializer.Deserialize(stream.ReadBytes(len).Data, this._receiveType);

        }

        public void FrameRecovery(byte[] buffer)
        {

        }

        public ArraySegment<byte> FrameSerialize(DataFrame packet, object body)
        {
            return new ArraySegment<byte>(
                 _webSocketSerializer.Serialize(body)
                );
        }
    }
}
