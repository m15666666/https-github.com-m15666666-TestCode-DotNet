using BeetleX;
using BeetleX.FastHttpApi;
using BeetleX.FastHttpApi.WebSockets;

using SampleWebSocket.Models;

using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace SampleWebSocket.Common
{
    public class BeetleXConnection<TReceive> : WebSocketConnectionBase<TReceive>
         where TReceive : WebSocketMessage
    {
        /// <summary>
        /// 连接实例
        /// </summary>
        readonly ISession _session;

        readonly HttpApiServer _httpServer;

        public override event EventHandler<TReceive> OnReceive;
        public override event EventHandler<Exception> OnException;
        public override event EventHandler<string> OnDisconnect;

        public BeetleXConnection(HttpApiServer httpServer, string identifier, ISession session)
        {
            this._httpServer = httpServer;
            this._identifier = identifier;
            this._session = session;
            this._originalIdentifier = this._session.ID.ToString();

        }

        public virtual bool IsDisposed => this._session.IsDisposed;


        public virtual void Receive(TReceive msg)
        {
            msg.SId = this._identifier;
            // 分发
            if (string.IsNullOrWhiteSpace(msg.CmdId))
            {
                // 普通消息
                this.OnReceive?.Invoke(this, msg);
            }
            else
            {
                // 下发命令回调
                _callbackChannel.Writer.TryWrite(msg);
            }
        }

        public virtual void Disconnect()
        {
            this.OnDisconnect?.Invoke(this, string.Empty);
        }

        public override int GetHashCode()
        {
            return this._session.GetHashCode();
        }

        public override async Task Send(object input, CancellationToken cancellationToken = default)
        {
            await Task.Yield();

            if (input is DataFrame)
            {
                this._session.Server.Send(input, this._session);
            }
            else
            {
                var dataFrame = _httpServer.CreateDataFrame(input);
                this._session.Server.Send(dataFrame, this._session);
            }
        }

        protected override async ValueTask SelfDisposeAsync()
        {
            _session.Dispose();
            await Task.CompletedTask;
        }
    }
}
