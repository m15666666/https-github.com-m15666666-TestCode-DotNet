using System;
using System.Collections.Generic;
using System.Text;

using Newtonsoft.Json;

namespace SampleWebSocket.Models
{
    public class WebSocketMessage
    {
        /// <summary>
        /// 会话id
        /// </summary>
        public string SId { get; set; }


        /// <summary>
        /// 上传数据Id，不为空时需要回复下位机
        /// </summary>
        public string UpId { get; set; }

        /// <summary>
        /// 下发指令的id,不为空时为消息下发回调
        /// </summary>
        public string CmdId { get; set; }


        /// <summary>
        /// 数据
        /// </summary>
        public object Data { get; set; }
    }
}
