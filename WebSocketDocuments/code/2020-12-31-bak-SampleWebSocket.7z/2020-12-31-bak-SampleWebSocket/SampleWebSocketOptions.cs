using JetBrains.Annotations;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

using Riven;

using SampleWebSocket.Hubs;
using SampleWebSocket.Models;

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.AspNetCore.Builder
{
    public class SampleWebSocketOptions : WebSocketOptions
    {
        public SampleWebSocketOptions()
        {
            this.ReceiveBufferSize = 1024;
            Routes = new Dictionary<string, SampleWebSocketRoute>();
        }

        public Dictionary<string, SampleWebSocketRoute> Routes { get; }


        public void AddRoute<THub>(string url)
             where THub : ISampleWsHub<WebSocketMessage>
        {
            var route = SampleWebSocketRoute.Create<THub>(url);
            Routes[route.Url] = route;
        }
    }

    public class SampleWebSocketRoute
    {
        private SampleWebSocketRoute()
        {

        }

        public virtual string Name { get; private set; }
        public virtual string Url { get; private set; }
        public virtual Type HubType { get; private set; }


        public static SampleWebSocketRoute Create<THub>([NotNull] string url)
            where THub : ISampleWsHub<WebSocketMessage>
        {
            Check.NotNullOrWhiteSpace(url, nameof(url));

            url = url.Trim().TrimEnd('/').ToLower();
            if (!url.StartsWith("/"))
            {
                url = $"/{url}";
            }


            var route = new SampleWebSocketRoute();
            route.HubType = typeof(THub);
            route.Url = url;


            if (url == "/")
            {
                route.Name = url;
            }
            else
            {
                var urlArray = url.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
                route.Name = urlArray[urlArray.Length - 1];
            }
            return route;
        }
    }



}
