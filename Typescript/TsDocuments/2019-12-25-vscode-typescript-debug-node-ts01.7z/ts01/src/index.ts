
const hello: string = 'hello, Alan.Tang';
let a = {a1:'a1',a2:'a2'};
let b = {b1:'b1',b2:'b2', ...a};

console.log(hello);